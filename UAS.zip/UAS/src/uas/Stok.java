
package uas;

class Stok {

    private String Nama;
    private int Stock, harga_satuan;
    
    public String getNama() {
            return Nama;
    }

    public void setNama(String nama) {
            Nama = nama;
    }

    public int getStock() {
            return Stock;
    }

    public void setStock(int stock) {
            Stock = stock;
    }
    
    public int getHargaSatuan() {
            return harga_satuan;
    }

    public void setHargaSatuan(int hargaSatuan) {
            harga_satuan = hargaSatuan;
    }
}
