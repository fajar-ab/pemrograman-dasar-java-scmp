package uas;

public class Main {
    
    
    
    public static void main(String[] args) {
        
        
        Stok alat1 = new Stok();
        
        alat1.setNama("Pobloint");
        alat1.setStock(10);
        alat1.setHargaSatuan(2000);
        
        System.out.println("Nama         : " + alat1.getNama());
	System.out.println("Stok         : " + alat1.getStock());
	System.out.println("Harga Satuan : " + alat1.getHargaSatuan());
        int tl1 = totalHarga(alat1.getStock(), alat1.getHargaSatuan());
        System.out.printf("Total Harga  : %,d\n", tl1);
        
        System.out.println("");
        Stok alat2 = new Stok();
        
        alat2.setNama("Pensil");
        alat2.setStock(10);
        alat2.setHargaSatuan(1000);
        
        System.out.println("Nama         : " + alat2.getNama());
	System.out.println("Stok         : " + alat2.getStock());
	System.out.println("Harga Satuan : " + alat2.getHargaSatuan());
        int tl2 = totalHarga(alat2.getStock(), alat2.getHargaSatuan());
        System.out.printf("Total Harga  : %,d\n", tl2);
        
        System.out.println("");
        Stok alat3 = new Stok();
        
        alat3.setNama("Penghapus");
        alat3.setStock(10);
        alat3.setHargaSatuan(500);
        
        
        System.out.println("Nama         : " + alat3.getNama());
	System.out.println("Stok         : " + alat3.getStock());
	System.out.println("Harga Satuan : " + alat3.getHargaSatuan());
        int tl3 = totalHarga(alat3.getStock(), alat3.getHargaSatuan());
        System.out.printf("Total Harga  : %,d\n", tl3);
        
        
        int semua = totalSemuaHarga(tl1, tl2, tl3);
        System.out.printf("\nTotal Semua Harga  : %,d\n", semua);
        
    }
    
    public static int totalHarga(int jumlahStok, int hargaPer){
        
        return jumlahStok * hargaPer;
        
    }
    
    public static int totalSemuaHarga(int al1, int al2, int al3){
        
        return al1 + al2 + al3;
        
    }
}
